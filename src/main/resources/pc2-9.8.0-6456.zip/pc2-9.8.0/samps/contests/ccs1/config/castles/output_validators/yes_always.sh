#!/bin/bash
#
# Purpose: output validator return 42 (Yes) for anything
#

exit 42

