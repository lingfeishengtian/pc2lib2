
//
// File:    nooutput.cpp
// Purpose: exits with no output
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
//
// $Id$
//

using namespace std;

main()
{
}

// eof 
