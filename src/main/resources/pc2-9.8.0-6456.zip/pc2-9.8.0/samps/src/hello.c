/* Copyright (C) 1989-2019 PC2 Development Team: John Clevenger, Douglas Lane, Samir Ashoo, and Troy Boudreau. */
/*
 * File:    hello.c 
 * Purpose: prints: Hello World.
 * Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
 *
 * $Id$
 *
 */

#include <stdio.h>
#include <stdlib.h>

main()
{
        printf("Hello World.\n");
        
        exit(0);
}

/* eof */
